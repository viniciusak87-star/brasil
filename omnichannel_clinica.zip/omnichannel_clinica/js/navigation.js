// ===== SISTEMA DE NAVEGAÇÃO =====

// Mapeamento de títulos das páginas
const pageTitles = {
    dashboard: 'Dashboard',
    inbox: 'Caixa de Entrada',
    conversas: 'Conversas',
    agenda: 'Agenda Médica',
    relatorios: 'Relatórios de Desempenho',
    usuarios: 'Gerenciamento de Usuários'
};

// Inicializar navegação
document.addEventListener('DOMContentLoaded', function() {
    setupNavigation();
    setupFilters();
    setupEventListeners();
});

// Configurar navegação
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remover classe active de todos os links
            navLinks.forEach(l => l.classList.remove('active'));
            
            // Adicionar classe active ao link clicado
            this.classList.add('active');
            
            // Obter página
            const page = this.getAttribute('data-page');
            
            // Atualizar título
            document.getElementById('page-title').textContent = pageTitles[page];
            
            // Mostrar página
            showPage(page);
        });
    });
}

// Mostrar página específica
function showPage(pageName) {
    // Esconder todas as páginas
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    // Mostrar página selecionada
    const selectedPage = document.getElementById(pageName);
    if (selectedPage) {
        selectedPage.classList.add('active');
    }
}

// Configurar filtros da caixa de entrada
function setupFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remover active de todos
            filterBtns.forEach(b => b.classList.remove('active'));
            
            // Adicionar active ao clicado
            this.classList.add('active');
            
            // Aplicar filtro
            const filter = this.getAttribute('data-filter');
            filterInboxItems(filter);
        });
    });
}

// Filtrar itens da caixa de entrada
function filterInboxItems(filter) {
    const items = document.querySelectorAll('.inbox-item');
    
    items.forEach(item => {
        if (filter === 'all') {
            item.style.display = 'flex';
        } else if (filter === 'unread' && item.classList.contains('unread')) {
            item.style.display = 'flex';
        } else if (filter === 'pending' && item.classList.contains('pending')) {
            item.style.display = 'flex';
        } else if (filter === 'resolved' && item.classList.contains('resolved')) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// Configurar event listeners gerais
function setupEventListeners() {
    // Busca
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            handleSearch(this.value);
        });
    }
    
    // Logout
    const logoutBtn = document.querySelector('.logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            if (confirm('Tem certeza que deseja sair?')) {
                alert('Você foi desconectado com sucesso!');
                // Aqui você redirecionaria para página de login
            }
        });
    }
    
    // Notificações
    const notifBtn = document.querySelector('.notif-btn');
    if (notifBtn) {
        notifBtn.addEventListener('click', function() {
            showNotifications();
        });
    }
    
    // Itens da caixa de entrada
    const inboxItems = document.querySelectorAll('.inbox-item');
    inboxItems.forEach(item => {
        item.addEventListener('click', function() {
            // Marcar como lido
            this.classList.remove('unread');
            
            // Selecionar conversa
            selectConversation(this);
        });
    });
    
    // Itens do chat
    const chatItems = document.querySelectorAll('.chat-item');
    chatItems.forEach(item => {
        item.addEventListener('click', function() {
            // Remover active de todos
            chatItems.forEach(i => i.classList.remove('active'));
            
            // Adicionar active ao clicado
            this.classList.add('active');
        });
    });
    
    // Botão de enviar mensagem
    const sendBtn = document.querySelector('.send-btn');
    if (sendBtn) {
        sendBtn.addEventListener('click', sendMessage);
    }
    
    // Enter para enviar mensagem
    const messageInput = document.getElementById('message-input');
    if (messageInput) {
        messageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
    
    // Respostas rápidas
    const quickReplies = document.querySelectorAll('.quick-reply');
    quickReplies.forEach(reply => {
        reply.addEventListener('click', function() {
            const messageInput = document.getElementById('message-input');
            if (messageInput) {
                messageInput.value = this.textContent;
            }
        });
    });
    
    // Botão de novo agendamento
    const newAgendaBtn = document.querySelector('.agenda-header .btn-primary');
    if (newAgendaBtn) {
        newAgendaBtn.addEventListener('click', function() {
            alert('Funcionalidade de novo agendamento será implementada em breve!');
        });
    }
    
    // Slots de agenda
    const slots = document.querySelectorAll('.slot');
    slots.forEach(slot => {
        slot.addEventListener('click', function() {
            if (this.classList.contains('available')) {
                alert('Agendar neste horário?');
            }
        });
    });
    
    // Botão de adicionar usuário
    const addUserBtn = document.querySelector('.users-header .btn-primary');
    if (addUserBtn) {
        addUserBtn.addEventListener('click', function() {
            alert('Funcionalidade de adicionar usuário será implementada em breve!');
        });
    }
    
    // Links de ação em usuários
    const actionLinks = document.querySelectorAll('.action-link');
    actionLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            if (this.classList.contains('delete')) {
                if (confirm('Tem certeza que deseja remover este usuário?')) {
                    alert('Usuário removido com sucesso!');
                }
            } else {
                alert('Funcionalidade de edição será implementada em breve!');
            }
        });
    });
}

// Função de busca
function handleSearch(query) {
    if (query.trim() === '') {
        // Mostrar todos os itens
        const items = document.querySelectorAll('.inbox-item, .chat-item, .recent-item');
        items.forEach(item => {
            item.style.display = '';
        });
        return;
    }
    
    const queryLower = query.toLowerCase();
    
    // Buscar em caixa de entrada
    const inboxItems = document.querySelectorAll('.inbox-item');
    inboxItems.forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(queryLower) ? 'flex' : 'none';
    });
    
    // Buscar em conversas
    const chatItems = document.querySelectorAll('.chat-item');
    chatItems.forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(queryLower) ? 'flex' : 'none';
    });
    
    // Buscar em atendimentos recentes
    const recentItems = document.querySelectorAll('.recent-item');
    recentItems.forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(queryLower) ? 'flex' : 'none';
    });
}

// Função para mostrar notificações
function showNotifications() {
    const notifications = [
        'Nova mensagem de Maria José Silva',
        'Lembrete: Consulta de João Carlos em 30 minutos',
        'Resultado de exame disponível para Lucia Pereira'
    ];
    
    alert('Notificações:\n\n' + notifications.join('\n'));
}

// Função para selecionar conversa
function selectConversation(item) {
    const name = item.querySelector('.item-header h4').textContent;
    const message = item.querySelector('.item-preview').textContent;
    
    // Atualizar chat
    const chatHeader = document.querySelector('.chat-header-info h3');
    if (chatHeader) {
        chatHeader.textContent = name;
    }
    
    // Você poderia atualizar as mensagens aqui também
    console.log('Conversa selecionada:', name);
}

// Função para enviar mensagem
function sendMessage() {
    const messageInput = document.getElementById('message-input');
    const message = messageInput.value.trim();
    
    if (message === '') {
        alert('Digite uma mensagem!');
        return;
    }
    
    // Criar elemento de mensagem
    const chatMessages = document.querySelector('.chat-messages');
    const messageElement = document.createElement('div');
    messageElement.className = 'message sent';
    
    const time = new Date().toLocaleTimeString('pt-BR', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    messageElement.innerHTML = `
        <p>${message}</p>
        <span class="message-time">${time}</span>
    `;
    
    chatMessages.appendChild(messageElement);
    
    // Limpar input
    messageInput.value = '';
    
    // Scroll para o final
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Simular resposta após 2 segundos
    setTimeout(() => {
        const responseElement = document.createElement('div');
        responseElement.className = 'message received';
        
        const responses = [
            'Obrigado pela mensagem! Estou aqui para ajudar.',
            'Entendi. Deixe-me verificar essa informação para você.',
            'Perfeito! Vou processar seu pedido agora.',
            'Tem mais alguma dúvida que eu possa esclarecer?'
        ];
        
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        const responseTime = new Date().toLocaleTimeString('pt-BR', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        responseElement.innerHTML = `
            <p>${randomResponse}</p>
            <span class="message-time">${responseTime}</span>
        `;
        
        chatMessages.appendChild(responseElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 2000);
}

// Exportar funções para uso global
window.showPage = showPage;
window.handleSearch = handleSearch;
