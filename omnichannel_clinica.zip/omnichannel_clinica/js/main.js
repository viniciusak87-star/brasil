// ===== ARQUIVO PRINCIPAL DO SISTEMA OMNICHANNEL =====

// Configurações gerais
const CONFIG = {
    appName: 'Sistema Omnichannel - Clínica Médica',
    version: '1.0.0',
    debug: true
};

// Utilitários
const Utils = {
    log: function(message, data = null) {
        if (CONFIG.debug) {
            console.log(`[${CONFIG.appName}] ${message}`, data || '');
        }
    },
    
    formatTime: function(date) {
        return date.toLocaleTimeString('pt-BR', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    },
    
    formatDate: function(date) {
        return date.toLocaleDateString('pt-BR', { 
            day: '2-digit', 
            month: '2-digit', 
            year: 'numeric' 
        });
    },
    
    getInitials: function(name) {
        return name
            .split(' ')
            .map(word => word[0])
            .join('')
            .toUpperCase()
            .slice(0, 2);
    },
    
    showAlert: function(message, type = 'info') {
        // Implementar sistema de notificação customizado
        console.log(`[${type.toUpperCase()}] ${message}`);
    }
};

// Gerenciador de estado da aplicação
const AppState = {
    usuarioAtual: {
        id: 1,
        nome: 'Ana Torres',
        email: 'ana.torres@clinica.com',
        funcao: 'Atendente',
        avatar: 'AT'
    },
    
    paginaAtual: 'dashboard',
    
    filtroAtual: 'all',
    
    conversaSelecionada: null,
    
    getUsuario: function() {
        return this.usuarioAtual;
    },
    
    setUsuario: function(usuario) {
        this.usuarioAtual = usuario;
    },
    
    getPaginaAtual: function() {
        return this.paginaAtual;
    },
    
    setPaginaAtual: function(pagina) {
        this.paginaAtual = pagina;
    }
};

// Gerenciador de API (simulado)
const APIManager = {
    baseURL: '/api',
    
    // Simular chamadas de API
    async getConversas() {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(window.conversas || []);
            }, 300);
        });
    },
    
    async getPacientes() {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(window.pacientes || []);
            }, 300);
        });
    },
    
    async getMetricas() {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(window.metricas || {});
            }, 300);
        });
    },
    
    async enviarMensagem(conversaId, mensagem) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({ sucesso: true, id: Date.now() });
            }, 500);
        });
    },
    
    async agendar(dados) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({ sucesso: true, id: Date.now() });
            }, 500);
        });
    },
    
    async criarUsuario(dados) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({ sucesso: true, id: Date.now() });
            }, 500);
        });
    }
};

// Gerenciador de eventos customizados
const EventManager = {
    eventos: {},
    
    on: function(evento, callback) {
        if (!this.eventos[evento]) {
            this.eventos[evento] = [];
        }
        this.eventos[evento].push(callback);
    },
    
    off: function(evento, callback) {
        if (this.eventos[evento]) {
            this.eventos[evento] = this.eventos[evento].filter(cb => cb !== callback);
        }
    },
    
    emit: function(evento, dados) {
        if (this.eventos[evento]) {
            this.eventos[evento].forEach(callback => callback(dados));
        }
    }
};

// Gerenciador de armazenamento local
const StorageManager = {
    set: function(chave, valor) {
        try {
            localStorage.setItem(chave, JSON.stringify(valor));
        } catch (e) {
            Utils.log('Erro ao salvar em localStorage', e);
        }
    },
    
    get: function(chave) {
        try {
            const valor = localStorage.getItem(chave);
            return valor ? JSON.parse(valor) : null;
        } catch (e) {
            Utils.log('Erro ao recuperar de localStorage', e);
            return null;
        }
    },
    
    remove: function(chave) {
        try {
            localStorage.removeItem(chave);
        } catch (e) {
            Utils.log('Erro ao remover de localStorage', e);
        }
    },
    
    clear: function() {
        try {
            localStorage.clear();
        } catch (e) {
            Utils.log('Erro ao limpar localStorage', e);
        }
    }
};

// Gerenciador de temas
const ThemeManager = {
    temaAtual: 'light',
    
    init: function() {
        this.temaAtual = StorageManager.get('tema') || 'light';
        this.aplicarTema(this.temaAtual);
    },
    
    aplicarTema: function(tema) {
        document.documentElement.setAttribute('data-theme', tema);
        this.temaAtual = tema;
        StorageManager.set('tema', tema);
    },
    
    alternarTema: function() {
        const novoTema = this.temaAtual === 'light' ? 'dark' : 'light';
        this.aplicarTema(novoTema);
    }
};

// Gerenciador de permissões
const PermissaoManager = {
    permissoes: {
        'atendente': ['visualizar_conversas', 'enviar_mensagens', 'agendar_consultas'],
        'gerente': ['visualizar_conversas', 'enviar_mensagens', 'agendar_consultas', 'gerenciar_usuarios', 'visualizar_relatorios'],
        'admin': ['*']
    },
    
    temPermissao: function(funcao, acao) {
        const permissoes = this.permissoes[funcao];
        if (!permissoes) return false;
        if (permissoes.includes('*')) return true;
        return permissoes.includes(acao);
    },
    
    verificarPermissao: function(acao) {
        const usuario = AppState.getUsuario();
        return this.temPermissao(usuario.funcao.toLowerCase(), acao);
    }
};

// Inicialização da aplicação
class App {
    constructor() {
        this.init();
    }
    
    init() {
        Utils.log('Iniciando aplicação...');
        
        // Inicializar gerenciadores
        ThemeManager.init();
        this.setupEventListeners();
        this.loadInitialData();
        
        Utils.log('Aplicação iniciada com sucesso!');
    }
    
    setupEventListeners() {
        // Logout
        const logoutBtn = document.querySelector('.logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.logout());
        }
        
        // Notificações
        const notifBtn = document.querySelector('.notif-btn');
        if (notifBtn) {
            notifBtn.addEventListener('click', () => this.showNotifications());
        }
    }
    
    async loadInitialData() {
        try {
            const conversas = await APIManager.getConversas();
            const metricas = await APIManager.getMetricas();
            
            Utils.log('Dados carregados com sucesso', { conversas, metricas });
        } catch (e) {
            Utils.log('Erro ao carregar dados iniciais', e);
        }
    }
    
    logout() {
        if (confirm('Tem certeza que deseja sair?')) {
            StorageManager.clear();
            alert('Você foi desconectado com sucesso!');
            // Redirecionar para página de login
            // window.location.href = '/login';
        }
    }
    
    showNotifications() {
        const notificacoes = window.notificacaoManager?.getNotificacoes() || [];
        
        if (notificacoes.length === 0) {
            alert('Nenhuma notificação no momento.');
            return;
        }
        
        const mensagem = notificacoes
            .map(n => `${n.titulo}: ${n.descricao}`)
            .join('\n');
        
        alert(`Notificações:\n\n${mensagem}`);
    }
}

// Inicializar aplicação quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    window.app = new App();
    window.utils = Utils;
    window.appState = AppState;
    window.apiManager = APIManager;
    window.eventManager = EventManager;
    window.storageManager = StorageManager;
    window.themeManager = ThemeManager;
    window.permissaoManager = PermissaoManager;
});

// Exportar para uso global
window.CONFIG = CONFIG;
