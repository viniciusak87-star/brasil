// ===== SISTEMA DE CHAT E MENSAGENS =====

// Dados simulados de conversas
const conversas = [
    {
        id: 1,
        paciente: 'Maria José Silva',
        avatar: 'MJ',
        canal: 'whatsapp',
        status: 'ativo',
        ultimaMensagem: 'Gostaria de agendar uma consulta com o Dr. Carlos',
        hora: '5 min atrás',
        naoLidas: 2,
        mensagens: [
            { tipo: 'recebida', texto: 'Olá! Gostaria de agendar uma consulta com o Dr. Carlos', hora: '10:30' },
            { tipo: 'recebida', texto: 'Ele atende na próxima semana?', hora: '10:31' },
            { tipo: 'enviada', texto: 'Olá Maria! Sim, o Dr. Carlos tem disponibilidade. Qual dia você prefere?', hora: '10:32' },
            { tipo: 'enviada', texto: 'Temos horários na segunda-feira às 14h ou na quarta-feira às 10h', hora: '10:33' },
            { tipo: 'recebida', texto: 'Perfeito! Segunda-feira às 14h está ótimo para mim', hora: '10:35' }
        ]
    },
    {
        id: 2,
        paciente: 'João Carlos',
        avatar: 'JC',
        canal: 'email',
        status: 'inativo',
        ultimaMensagem: 'Preciso remarcar minha consulta de amanhã',
        hora: '15 min atrás',
        naoLidas: 1,
        mensagens: [
            { tipo: 'recebida', texto: 'Preciso remarcar minha consulta de amanhã, não vou conseguir ir', hora: '10:15' },
            { tipo: 'enviada', texto: 'Sem problema, João! Qual seria a data preferida?', hora: '10:20' }
        ]
    },
    {
        id: 3,
        paciente: 'Lucia Pereira',
        avatar: 'LP',
        canal: 'instagram',
        status: 'inativo',
        ultimaMensagem: 'Quando saem meus resultados de exame?',
        hora: '30 min atrás',
        naoLidas: 0,
        mensagens: [
            { tipo: 'recebida', texto: 'Quando saem meus resultados de exame? Estou preocupada...', hora: '09:30' },
            { tipo: 'enviada', texto: 'Oi Lucia! Seus resultados devem sair até amanhã. Vou avisá-la assim que chegarem!', hora: '09:45' }
        ]
    }
];

// Dados simulados de pacientes
const pacientes = [
    {
        id: 1,
        nome: 'Maria José Silva',
        cpf: '123.456.789-00',
        email: 'maria@email.com',
        telefone: '(11) 98765-4321',
        dataNascimento: '15/03/1985',
        endereco: 'Rua das Flores, 123 - São Paulo, SP',
        especialidade: 'Cardiologia',
        medico: 'Dr. Carlos',
        ultimaConsulta: '10/11/2025',
        proximaConsulta: '18/11/2025 às 14h'
    }
];

// Dados simulados de métricas
const metricas = {
    atendimentosHoje: 24,
    tempoMedioResposta: 150, // em segundos
    taxaResolucao: 87,
    consultasAgendadas: 18,
    canais: {
        whatsapp: { total: 12, naoLidas: 3 },
        email: { total: 8, naoLidas: 2 },
        instagram: { total: 4, naoLidas: 1 },
        facebook: { total: 3, naoLidas: 0 }
    }
};

// Classe para gerenciar chat
class ChatManager {
    constructor() {
        this.conversaAtual = null;
        this.init();
    }
    
    init() {
        this.setupChatItems();
        this.setupMessageInput();
        this.loadConversa(conversas[0]);
    }
    
    setupChatItems() {
        const chatItems = document.querySelectorAll('.chat-item');
        chatItems.forEach((item, index) => {
            item.addEventListener('click', () => {
                this.selectChat(index);
            });
        });
    }
    
    selectChat(index) {
        const chatItems = document.querySelectorAll('.chat-item');
        chatItems.forEach(item => item.classList.remove('active'));
        chatItems[index].classList.add('active');
        
        this.loadConversa(conversas[index]);
    }
    
    loadConversa(conversa) {
        this.conversaAtual = conversa;
        
        // Atualizar header
        const headerInfo = document.querySelector('.chat-header-info');
        headerInfo.innerHTML = `
            <h3>${conversa.paciente}</h3>
            <p class="chat-status">${conversa.status === 'ativo' ? 'Ativo agora' : 'Inativo'}</p>
        `;
        
        // Carregar mensagens
        this.loadMessages(conversa);
    }
    
    loadMessages(conversa) {
        const chatMessages = document.querySelector('.chat-messages');
        chatMessages.innerHTML = '';
        
        conversa.mensagens.forEach(msg => {
            const messageElement = document.createElement('div');
            messageElement.className = `message ${msg.tipo === 'enviada' ? 'sent' : 'received'}`;
            messageElement.innerHTML = `
                <p>${msg.texto}</p>
                <span class="message-time">${msg.hora}</span>
            `;
            chatMessages.appendChild(messageElement);
        });
        
        // Scroll para o final
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    setupMessageInput() {
        const sendBtn = document.querySelector('.send-btn');
        const messageInput = document.getElementById('message-input');
        
        if (sendBtn) {
            sendBtn.addEventListener('click', () => this.sendMessage());
        }
        
        if (messageInput) {
            messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }
    }
    
    sendMessage() {
        const messageInput = document.getElementById('message-input');
        const message = messageInput.value.trim();
        
        if (!message || !this.conversaAtual) return;
        
        // Adicionar mensagem ao histórico
        const time = new Date().toLocaleTimeString('pt-BR', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        this.conversaAtual.mensagens.push({
            tipo: 'enviada',
            texto: message,
            hora: time
        });
        
        // Atualizar display
        this.loadMessages(this.conversaAtual);
        messageInput.value = '';
        
        // Simular resposta
        this.simulateResponse();
    }
    
    simulateResponse() {
        setTimeout(() => {
            const responses = [
                'Obrigado pela mensagem! Estou aqui para ajudar.',
                'Entendi. Deixe-me verificar essa informação para você.',
                'Perfeito! Vou processar seu pedido agora.',
                'Tem mais alguma dúvida que eu possa esclarecer?',
                'Tudo bem! Vou anotar isso para você.'
            ];
            
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            const time = new Date().toLocaleTimeString('pt-BR', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            
            this.conversaAtual.mensagens.push({
                tipo: 'recebida',
                texto: randomResponse,
                hora: time
            });
            
            this.loadMessages(this.conversaAtual);
        }, 1500);
    }
}

// Classe para gerenciar métricas
class MetricasManager {
    constructor() {
        this.metricas = metricas;
        this.init();
    }
    
    init() {
        this.updateDashboard();
    }
    
    updateDashboard() {
        // Atualizar cards de estatísticas
        const stats = document.querySelectorAll('.stats-card');
        
        if (stats[0]) {
            stats[0].querySelector('.stat-number').textContent = this.metricas.atendimentosHoje;
        }
        
        if (stats[1]) {
            const minutos = Math.floor(this.metricas.tempoMedioResposta / 60);
            const segundos = this.metricas.tempoMedioResposta % 60;
            stats[1].querySelector('.stat-number').textContent = `${minutos}m ${segundos}s`;
        }
        
        if (stats[2]) {
            stats[2].querySelector('.stat-number').textContent = this.metricas.taxaResolucao + '%';
        }
        
        if (stats[3]) {
            stats[3].querySelector('.stat-number').textContent = this.metricas.consultasAgendadas;
        }
    }
    
    getMetricasPorCanal() {
        return this.metricas.canais;
    }
    
    getTempoMedioResposta() {
        return this.metricas.tempoMedioResposta;
    }
    
    getTaxaResolucao() {
        return this.metricas.taxaResolucao;
    }
}

// Classe para gerenciar filtros
class FiltroManager {
    constructor() {
        this.filtroAtual = 'all';
        this.init();
    }
    
    init() {
        this.setupFiltros();
    }
    
    setupFiltros() {
        const filterBtns = document.querySelectorAll('.filter-btn');
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.filtroAtual = btn.getAttribute('data-filter');
                this.aplicarFiltro();
            });
        });
    }
    
    aplicarFiltro() {
        const items = document.querySelectorAll('.inbox-item');
        
        items.forEach(item => {
            let mostrar = false;
            
            if (this.filtroAtual === 'all') {
                mostrar = true;
            } else if (this.filtroAtual === 'unread' && item.classList.contains('unread')) {
                mostrar = true;
            } else if (this.filtroAtual === 'pending' && item.classList.contains('pending')) {
                mostrar = true;
            } else if (this.filtroAtual === 'resolved' && item.classList.contains('resolved')) {
                mostrar = true;
            }
            
            item.style.display = mostrar ? 'flex' : 'none';
        });
    }
}

// Classe para gerenciar notificações
class NotificacaoManager {
    constructor() {
        this.notificacoes = [
            { tipo: 'nova_mensagem', titulo: 'Nova mensagem', descricao: 'Maria José Silva enviou uma mensagem', tempo: '5 min atrás' },
            { tipo: 'lembrete', titulo: 'Lembrete de consulta', descricao: 'Consulta de João Carlos em 30 minutos', tempo: '10 min atrás' },
            { tipo: 'resultado', titulo: 'Resultado disponível', descricao: 'Resultado de exame para Lucia Pereira', tempo: '15 min atrás' }
        ];
    }
    
    getNotificacoes() {
        return this.notificacoes;
    }
    
    adicionarNotificacao(notificacao) {
        this.notificacoes.unshift(notificacao);
    }
    
    limparNotificacoes() {
        this.notificacoes = [];
    }
}

// Classe para gerenciar busca
class BuscaManager {
    constructor() {
        this.setupBusca();
    }
    
    setupBusca() {
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.buscar(e.target.value);
            });
        }
    }
    
    buscar(query) {
        if (!query.trim()) {
            this.mostrarTodos();
            return;
        }
        
        const queryLower = query.toLowerCase();
        
        // Buscar em inbox
        const inboxItems = document.querySelectorAll('.inbox-item');
        inboxItems.forEach(item => {
            const texto = item.textContent.toLowerCase();
            item.style.display = texto.includes(queryLower) ? 'flex' : 'none';
        });
        
        // Buscar em chat
        const chatItems = document.querySelectorAll('.chat-item');
        chatItems.forEach(item => {
            const texto = item.textContent.toLowerCase();
            item.style.display = texto.includes(queryLower) ? 'flex' : 'none';
        });
    }
    
    mostrarTodos() {
        const items = document.querySelectorAll('.inbox-item, .chat-item');
        items.forEach(item => {
            item.style.display = '';
        });
    }
}

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    window.chatManager = new ChatManager();
    window.metricasManager = new MetricasManager();
    window.filtroManager = new FiltroManager();
    window.notificacaoManager = new NotificacaoManager();
    window.buscaManager = new BuscaManager();
    
    console.log('Sistema Omnichannel inicializado com sucesso!');
});

// Exportar dados para uso global
window.conversas = conversas;
window.pacientes = pacientes;
window.metricas = metricas;
